package com.cg.ibs.rm.bean;

public class BankRepresentative {
	private String response;

	public BankRepresentative() {
		super();
	}

	public BankRepresentative(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

}
