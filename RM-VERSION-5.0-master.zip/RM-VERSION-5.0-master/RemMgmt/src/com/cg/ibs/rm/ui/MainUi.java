package com.cg.ibs.rm.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.service.AutoPaymentService;
import com.cg.ibs.rm.service.AutoPaymentServiceImpl;
import com.cg.ibs.rm.service.BankRepresentativeService;
import com.cg.ibs.rm.service.BankRepresentativeServiceImpl;
import com.cg.ibs.rm.service.BeneficiaryAccountService;
import com.cg.ibs.rm.service.BeneficiaryAccountServiceImpl;
import com.cg.ibs.rm.service.CreditCardService;
import com.cg.ibs.rm.service.CreditCardServiceImpl;

public class MainUi {
	private static Scanner scanner;
	private static Iterator<CreditCard> itCredit;
	private static Iterator<Beneficiary> itBeneficiary;

	private CreditCardService cardService = new CreditCardServiceImpl();
	private BeneficiaryAccountService beneficiaryAccountService = new BeneficiaryAccountServiceImpl();
	private BankRepresentativeService bankRepresentativeService = new BankRepresentativeServiceImpl();
	private AutoPaymentService autopaymentservobj = new AutoPaymentServiceImpl();
	private String uci;

	private void Start() {
		MainMenu choice = null;
		while (MainMenu.QUIT != choice) {
			System.out.println("------------------------");
			System.out.println("Choose your identity from MENU:");
			System.out.println("------------------------");
			for (MainMenu menu : MainMenu.values()) {
				System.out.println((menu.ordinal()) + "\t" + menu);
			}
			System.out.println("Your choice :");// choosing of identity whether
												// user or bank representative
			int ordinal = scanner.nextInt();

			if (0 <= (ordinal) && MainMenu.values().length > ordinal) {
				choice = MainMenu.values()[ordinal];
				switch (choice) {
				case CUSTOMER:
					login();
					customerAction();
					break;
				case BANKREPRESENTATIVE:
					bankRepresentativeAction();
					break;
				case QUIT:
					System.out.println("Thankyou... Visit again!");
					break;
				}
			} else {
				System.out.println("Please enter a valid option.");
				choice = null;
			}
		}
	}

	private void login() {// to enter login details
		System.out.println("Customer id:");
		uci = scanner.next();
		System.out.println("Password");
		scanner.next();
		System.out.println("Logged in successfully!!");
	}

	private void customerAction() {// facilities provided to the ibs customer
		CustomerUi choice = null;
		System.out.println("------------------------");
		System.out.println("Choose a valid option");
		System.out.println("------------------------");
		for (CustomerUi menu : CustomerUi.values()) {
			System.out.println(menu.ordinal() + "\t" + menu);// showing options
																// to the
																// customer
		}
		System.out.println("Choices:");
		int ordinal = scanner.nextInt();

		if (0 <= ordinal && CustomerUi.values().length > ordinal) {
			choice = CustomerUi.values()[ordinal];
			switch (choice) {
			case CREDITCARD:
				System.out.println(cardService.showCardDetails(uci));
				addOrDeleteCreditCard();
				customerAction();
				break;
			case BENEFICIARY:
				System.out.println(beneficiaryAccountService.showBeneficiaryAccount(uci));
				addOrModifyBeneficiary();
				customerAction();
				break;
			case AUTOPAYMENT:
				addOrRemoveAutopayments();
				customerAction();
				break;
			case EXIT:
				System.out.println("BACK ON HOME PAGE!!");
				break;
			}
		} else {
			System.out.println("Please enter a valid option.");
			customerAction();
		}
	}

	private void addOrDeleteCreditCard() {
		CreditCard card = new CreditCard();
		int creditCardOption;
		do {
			System.out.println("Enter 1 to add a credit card \n2 for delete a credit card");
			creditCardOption = scanner.nextInt();// enter the credit card
													// facility to be used
			switch (creditCardOption) {
			case 1:
				System.out.println("Please Enter your CreditCard number (16 digits)");
				BigInteger cardNumber = scanner.nextBigInteger();
				boolean valid = cardService.validateCardNumber(cardNumber);
				if (valid) {
					card.setcreditCardNumber(cardNumber);
				} else {
					while (!valid) {
						System.out.println("Enter correct details again");
						cardNumber = scanner.nextBigInteger();
						valid = cardService.validateCardNumber(cardNumber);
					}
					card.setcreditCardNumber(cardNumber);
				}

				System.out.println("Please enter the Name on your CreditCard (Case Sensitive and no Space)");
				String nameOnCard = scanner.next();
				boolean valid2 = cardService.validateNameOnCard(nameOnCard);

				if (valid2) {

					card.setnameOnCreditCard(nameOnCard);
				} else {
					while (!valid2) {
						System.out.println("Enter correct details again");
						nameOnCard = scanner.next();
						valid2 = cardService.validateNameOnCard(nameOnCard);
					}
					card.setnameOnCreditCard(nameOnCard);
				}

				System.out.println(
						"Please enter the expiry date on your card number in (DD/MM/YYYY) format (enter date as 30)");
				String expiryDate = scanner.next();
				while (expiryDate.length() != 10) {
					System.out.println("Enter a Date that is not stupid  ");
					expiryDate = scanner.next();
				}
				if (expiryDate.length() == 10) {
					boolean valid3 = cardService.validateDateOfExpiry(expiryDate);
					if (valid3) {
						card.setcreditDateOfExpiry(expiryDate);
					} else {
						while (!valid3) {
							System.out.println("Enter correct details again");
							expiryDate = scanner.next();
							valid3 = cardService.validateDateOfExpiry(expiryDate);
						}
						card.setcreditDateOfExpiry(expiryDate);
					}
					try {
						cardService.saveCardDetails(uci, card);
						System.out.println("Card gone for approval.. Good luck!!");
					} catch (IBSExceptions exception) {
						System.out.println(exception.getMessage());
					}
				}
				break;
			case 2:
				System.out.println("Enter card number");
				BigInteger creditCardNumber = scanner.nextBigInteger();
				boolean valid5 = cardService.validateCardNumber(creditCardNumber);
				if (valid5) {
					try {
						cardService.deleteCardDetails(uci, creditCardNumber);
						System.out.println("Card deleted!!");
					} catch (IBSExceptions exception) {
						System.out.println(exception.getMessage());
					}
				} else {
					while (!valid5) {
						System.out.println("Enter correct details again");
						cardNumber = scanner.nextBigInteger();
						valid5 = cardService.validateCardNumber(cardNumber);
					}
				}
				break;
			default:
				System.out.println("Please enter a valid choice");
				creditCardOption = 0;
			}
		} while (0 == creditCardOption);
	}

	private void addOrModifyBeneficiary() {// beneficiary related facilities
											// provided in this section
		int beneficiaryOption;
		do {
			System.out.println(
					"Enter \n1 to add a beneficiary \n2 for modifying a beneficiary \n3 for delete a beneficiary");
			beneficiaryOption = scanner.nextInt();// choose the facility which
													// you want to use
			switch (beneficiaryOption) {
			case 1:
				Type choice = null;
				System.out.println("------------------------");
				System.out.println("Choose a valid option");
				System.out.println("------------------------");
				for (Type menu : Type.values()) {
					System.out.println(menu.ordinal() + "\t" + menu);
				}
				System.out.println("Choices:");
				int ordinal = scanner.nextInt();

				if (0 <= ordinal && CustomerUi.values().length > ordinal) {
					choice = Type.values()[ordinal];
					switch (choice) {
					case SELFINSAME:
						addBeneficiary(choice);
						break;
					case SELFINOTHERS:
						addBeneficiary(choice);
					case OTHERSINOTHERS:
						addBeneficiary(choice);
						break;
					case OTHERSINSAME:
						addBeneficiary(choice);
						break;
					}
				} else {
					System.out.println("Please enter a valid option.");
					customerAction();
				}
				break;
			case 2:
				System.out.println("Enter account number");
				BigInteger accountNumberToModify = scanner.nextBigInteger();
				int choiceToModify;
				do {
					System.out.println(
							"Enter 1 to change Account Holder Name\n2 to change IFSC code\n3to change bank name");
					choiceToModify = scanner.nextInt();
					switch (choiceToModify) {
					case 1:
						System.out.println("Enter new account holder name");
						String nameInAccount = scanner.next();
						boolean validName = beneficiaryAccountService
								.validateBeneficiaryAccountNameOrBankName(nameInAccount);

						if (validName) {
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										nameInAccount, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						} else {
							while (!validName) {
								System.out.println("Enter correct details again");
								nameInAccount = scanner.next();
								validName = beneficiaryAccountService
										.validateBeneficiaryAccountNameOrBankName(nameInAccount);
							}
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										nameInAccount, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						}
						break;
					case 2:
						System.out.println("Enter new IFSC code");
						String ifscNewValue = scanner.next();
						boolean validIfsc = beneficiaryAccountService.validateBeneficiaryIfscCode(ifscNewValue);

						if (validIfsc) {
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										ifscNewValue, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						} else {
							while (!validIfsc) {
								System.out.println("Enter correct details again");
								ifscNewValue = scanner.next();
								validIfsc = beneficiaryAccountService
										.validateBeneficiaryAccountNameOrBankName(ifscNewValue);
							}
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										ifscNewValue, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						}
						break;
					case 3:
						System.out.println("Enter new bank name");
						String bankNameNewValue = scanner.next();
						boolean validbankName = beneficiaryAccountService
								.validateBeneficiaryAccountNameOrBankName(bankNameNewValue);

						if (validbankName) {
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										bankNameNewValue, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						} else {
							while (!validbankName) {
								System.out.println("Enter correct details again");
								bankNameNewValue = scanner.next();
								validbankName = beneficiaryAccountService
										.validateBeneficiaryAccountNameOrBankName(bankNameNewValue);
							}
							try {
								beneficiaryAccountService.modifyBeneficiaryAccountDetails(choiceToModify, uci,
										bankNameNewValue, accountNumberToModify);
							} catch (IBSExceptions exception) {
								System.out.println(exception.getMessage());
							}
						}
						break;

					default:
						System.out.println("Wrong Input");
						choiceToModify = 0;
						break;
					}
				} while (0 == choiceToModify);
				System.out.println("Modified beneficiaries gone for approval");
				break;
			case 3:
				System.out.println("Enter account number to delete");
				BigInteger deleteAccountNum = scanner.nextBigInteger();
				try {
					beneficiaryAccountService.deleteBeneficiaryAccountDetails(uci, deleteAccountNum);
				} catch (IBSExceptions exception) {
					System.out.println(exception.getMessage());
				}
				break;
			default:
				System.out.println("Please enter a valid choice");
				beneficiaryOption = 0;
			}
		} while (0 == beneficiaryOption);
	}

	private void addBeneficiary(Type type) {
		Beneficiary beneficiary = new Beneficiary();
		System.out.println("Please Enter your Account number (12 digits)");
		BigInteger accountNumber = scanner.nextBigInteger();
		boolean valid = beneficiaryAccountService.validateBeneficiaryAccountNumber(accountNumber);
		if (valid) {
			beneficiary.setAccountNumber(accountNumber);
		} else {
			while (!valid) {
				System.out.println("Enter correct details again");
				accountNumber = scanner.nextBigInteger();
				valid = beneficiaryAccountService.validateBeneficiaryAccountNumber(accountNumber);
			}
			beneficiary.setAccountNumber(accountNumber);
		}

		System.out.println("Please enter the Account Holder Name (Case Sensitive)");
		String nameInAccount = scanner.next();
		boolean valid2 = beneficiaryAccountService.validateBeneficiaryAccountNameOrBankName(nameInAccount);

		if (valid2) {

			beneficiary.setAccountName(nameInAccount);
		} else {
			while (!valid2) {
				System.out.println("Enter correct details again");
				nameInAccount = scanner.next();
				valid2 = beneficiaryAccountService.validateBeneficiaryAccountNameOrBankName(nameInAccount);
			}
			beneficiary.setAccountName(nameInAccount);
		}

		System.out.println("Please enter IFSC code(11 characters)");
		String ifsc = scanner.next();
		boolean valid3 = beneficiaryAccountService.validateBeneficiaryIfscCode(ifsc);
		if (valid3) {

			beneficiary.setIfscCode(ifsc);
		} else {
			while (!valid3) {
				System.out.println("Enter correct details again");
				ifsc = scanner.next();
				valid3 = beneficiaryAccountService.validateBeneficiaryIfscCode(ifsc);
			}
			beneficiary.setIfscCode(ifsc);
		}

		System.out.println("Enter bank name (case sensitive)");
		String bankName = scanner.next();
		boolean valid4 = beneficiaryAccountService.validateBeneficiaryAccountNameOrBankName(bankName);

		if (valid4) {

			beneficiary.setBankName(bankName);
		} else {
			while (!valid4) {
				System.out.println("Enter correct details again");
				bankName = scanner.next();
				valid4 = beneficiaryAccountService.validateBeneficiaryAccountNameOrBankName(bankName);
			}
			beneficiary.setBankName(bankName);
		}
		beneficiary.setType(type);
		try {
			beneficiaryAccountService.saveBeneficiaryAccountDetails(uci, beneficiary);
			System.out.println("Beneficiary gone for approval... Good luck!!");
		} catch (IBSExceptions exception) {
			System.out.println(exception.getMessage());
		}
	}

	private void addOrRemoveAutopayments() {
		AutoPaymentUi choice = null;
		System.out.println("------------------------");
		System.out.println("Choose a valid option");
		System.out.println("------------------------");
		for (AutoPaymentUi menu : AutoPaymentUi.values()) {
			System.out.println(menu.ordinal() + "\t" + menu);
		}
		System.out.println("Choices:");
		int ordinal = scanner.nextInt();

		if (0 <= ordinal && AutoPaymentUi.values().length > ordinal) {
			choice = AutoPaymentUi.values()[ordinal];
			switch (choice) {
			case ADDAUTOPAYMENTS:

				addAutoPayment(); // this method is for adding auto payment
									// details
				addOrRemoveAutopayments();// this method is for showing auto
											// payment menu again
				break;
			case REMOVEAUTOPAYMENTS:
				removeAutoPayment();
				addOrRemoveAutopayments();
				break;
			case EXIT:
				System.out.println("BACK ON HOME PAGE!!");
				break;
			default:
				System.out.println("Enter a valid choice");
				addOrRemoveAutopayments();
			}
		} else {
			System.out.println("Please enter a valid option.");
			addOrRemoveAutopayments();
		}
	}

	private void addAutoPayment() {
		BigInteger input;// for service provider id as given by use case 5
		AutoPayment autoPayment = new AutoPayment();
		boolean check;
		System.out.println(autopaymentservobj.showIBSServiceProviders());
		System.out.println("Enter your Service provider Id");
		input = scanner.nextBigInteger();
		autoPayment.setServiceProviderId(input);
		System.out.println("Enter amount to be deducted");
		BigDecimal amount = scanner.nextBigDecimal();
		autoPayment.setAmount(amount);
		System.out.println("Enter your start date (in format dd/MM/yyyy)");
		String mydate = scanner.next();
		while (mydate.length() != 10) {
			System.out.println("Enter a Date that is not stupid ");
			mydate = scanner.next();
		}
		if (mydate.length() == 10) {
			autoPayment.setDateOfStart(mydate);
			try {
				check = autopaymentservobj.autoDeduction(uci, autoPayment);
				if (check) {
					System.out.println("AutoPayment of service provider: " + input + " added and Rs. " + amount
							+ " will be deducted per month from the date of start");
				} else {
					System.out.println("Autopayment service could not be added");
				}
			} catch (IBSExceptions exception) {
				System.out.println(exception.getMessage()); // validation of
															// date is
															// handled by the
															// exception
			}
		}
	}

	private void removeAutoPayment() {// removal of autopayment
		System.out.println(autopaymentservobj.showAutopaymentDetails(uci));
		System.out.println("Enter your sevice provider id to be removed");
		BigInteger input3 = scanner.nextBigInteger();
		try {
			autopaymentservobj.updateRequirements(uci, input3);
			System.out.println("Autopayment service removed successfully");
		} catch (IBSExceptions exception) {
			System.out.println(exception.getMessage());
		}
	}

	private void bankRepresentativeAction() {// user interface for bank
												// representative
		BankRepresentativeUi choice = null;
		System.out.println("------------------------");
		System.out.println("Choose a valid option");
		System.out.println("------------------------");
		for (BankRepresentativeUi menu : BankRepresentativeUi.values()) {
			System.out.println(menu.ordinal() + "\t" + menu);
		}
		System.out.println("Choices:");
		int ordinal = scanner.nextInt();

		if (0 <= ordinal && BankRepresentativeUi.values().length > ordinal) {
			choice = BankRepresentativeUi.values()[ordinal];
			switch (choice) {
			case VIEWREQUESTS:

				showRequests();

				break;
			case EXIT:
				System.out.println("BACK ON HOME PAGE!!");
				break;
			}
		} else {
			System.out.println("Please enter a valid option.");
			bankRepresentativeAction();
		}
	}

	private void showRequests() {
		System.out.println(bankRepresentativeService.showRequests());
		String uci;
		System.out.println("Please enter the customer id to view individual requests \nEnter 0 to exit");
		uci = scanner.next();
		while (!(uci.equals("0"))) {
			System.out.println("Id entered by you is : " + uci);
			int choice1;
			do {
				System.out.println(
						"Enter 1 to view Creditcard requests \nEnter 2 to view Beneficiary Requests \nEnter 3 to go to the previous list ");
				choice1 = scanner.nextInt();
				switch (choice1) {
				case 1:
					try {// showing credit card requests to bank representative
						itCredit = bankRepresentativeService.showUnapprovedCreditCards(uci).iterator();

						if (!(itCredit.hasNext())) {
							System.out.println("No more credit card requests");
							break;
						}
						while (itCredit.hasNext()) {
							CreditCard creditCard = itCredit.next();
							System.out.println(creditCard);
							int choice2;
							do {
								System.out.println(
										"Enter 1 to approve. \nEnter 2 to disapprove \n Enter 3 to Exit the section");
								choice2 = scanner.nextInt();
								switch (choice2) {
								case 1:
									bankRepresentativeService.saveCreditCardDetails(uci, creditCard);
									System.out.println("Card approved");
									bankRepresentativeService.removeTempCreditCardDetails(uci, creditCard);
									break;
								case 2:
									bankRepresentativeService.removeTempCreditCardDetails(uci, creditCard);
									System.out.println("Card disapproved");
									break;
								default:
									System.out.println("Enter a valid choice of decision of credit card");
									choice2 = 0;
								}
							} while (0 == choice2);
						}
					} catch (IBSExceptions exception) {
						exception.getMessage();
					}
					break;
				case 2:
					try {// showing beneficiary requests to bank representative
						itBeneficiary = bankRepresentativeService.showUnapprovedBeneficiaries(uci).iterator();

						if (!(itBeneficiary.hasNext())) {
							System.out.println("No more beneficiary requests");
							break;
						}
						while (itBeneficiary.hasNext()) {
							Beneficiary beneficiary = itBeneficiary.next();
							System.out.println(beneficiary);
							int choice2;
							do {
								System.out.println("Enter 1 to approve. \nEnter 2 to disapprove ");
								choice2 = scanner.nextInt();
								switch (choice2) {
								case 1:
									bankRepresentativeService.saveBeneficiaryDetails(uci, beneficiary);
									
									System.out.println("Beneficiary approved");
									bankRepresentativeService.removeTempBeneficiaryDetails(uci, beneficiary);
									break;
								case 2:
									bankRepresentativeService.removeTempBeneficiaryDetails(uci, beneficiary);
									System.out.println("Beneficiary disapproved");
									break;
								default:
									System.out.println("Enter a valid choice of decision of beneficiary");
									choice2 = 0;
								}
							} while (0 == choice2);
						}
					} catch (IBSExceptions exception) {
						System.out.println(exception.getMessage());
					}
					break;
				case 3:
					choice1 = 0;
					uci = "0";
					break;
				default:
					System.out.println("Enter a valid choice of action");
				}

			} while (0 != choice1);
			System.out.println("Please enter the customer id to view individual requests \nEnter 0 to exit");
			uci = scanner.next();
		}

	}

	public static void main(String[] args) {
		scanner = new Scanner(System.in);
		MainUi mainUii = new MainUi();
		mainUii.Start();
		scanner.close();
		System.out.println();
	}
}
